import tkinter as tk

# Año actual según la consigna
CURRENT_YEAR = 2025

def calcular_edad():
    year_text = entry_year.get().strip()
    if not year_text:
        result_label.config(text="Por favor ingrese un año.")
        return
    try:
        year = int(year_text)
    except ValueError:
        result_label.config(text="Ingrese un número entero válido.")
        return
    if year <= 0:
        result_label.config(text="Ingrese un año positivo.")
        return
    if year > CURRENT_YEAR:
        result_label.config(text=f"El año no puede ser mayor a {CURRENT_YEAR}.")
        return

    edad = CURRENT_YEAR - year
    result_label.config(text=f"Tienes aproximadamente {edad} años.")

# --- Interfaz gráfica ---
root = tk.Tk()
root.title("Calculadora de Edad")

label_prompt = tk.Label(root, text="Año de nacimiento:")
entry_year = tk.Entry(root)
button_calc = tk.Button(root, text="Calcular Edad", command=calcular_edad)
result_label = tk.Label(root, text="")

label_prompt.grid(row=0, column=0, padx=8, pady=8, sticky="e")
entry_year.grid(row=0, column=1, padx=8, pady=8, sticky="w")
button_calc.grid(row=1, column=0, columnspan=2, padx=8, pady=8)
result_label.grid(row=2, column=0, columnspan=2, padx=8, pady=8)

root.mainloop()
