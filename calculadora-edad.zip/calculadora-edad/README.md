# 🧮 Calculadora de Edad

Ejercicio práctico de Python (Tkinter) para calcular la edad de una persona según su año de nacimiento.  
El año actual se considera **2025**, según la consigna.

## 🚀 Cómo ejecutar

1. Asegúrate de tener **Python 3** instalado.  
2. Descarga este repositorio o el archivo `calculadora_edad.py`.  
3. En la terminal, ejecuta:

```bash
python calculadora_edad.py
```

Se abrirá una ventana gráfica donde podrás ingresar tu año de nacimiento y calcular tu edad.

## 📂 Estructura del proyecto

```
calculadora-edad/
│
├── calculadora_edad.py   # Programa principal
└── README.md             # Explicación del proyecto
```

## ✨ Ejemplo

- Si ingresas `2000`, el programa mostrará:  
  **"Tienes aproximadamente 25 años."**

---

✍️ Autor: *Tu usuario de GitHub*
